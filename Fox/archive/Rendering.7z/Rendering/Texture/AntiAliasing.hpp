#pragma once

#include "stdafx.hpp"

namespace fox::gfx::api
{
    enum class AntiAliasing
    {
        None,
        MSAA,
    };
}
