#pragma once

#include "stdafx.hpp"

namespace fox::gfx::api
{
    class Renderer
    {
    protected:
        Renderer() = default;
    };
}
