#pragma once

namespace fox::gfx::api
{
    class VertexArray
    {
    protected:
        VertexArray() = default;
    };
}
