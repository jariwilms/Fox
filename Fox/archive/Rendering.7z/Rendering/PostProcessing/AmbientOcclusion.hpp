#pragma once

#include "stdafx.hpp"

#include "PostProcessing.hpp"

namespace fox::gfx
{
    //struct AmbientOcclusionOption : PostProcessingOption
    //{
    //
    //};
}
