#include "Fox/Rendering/Using.hpp"

#if FOX_GRAPHICS_API == OpenGL
#include "Fox/Rendering/API/OpenGL/OpenGL.hpp"
#endif

#if FOX_GRAPHICS_API == Vulkan
//#include "Fox/Rendering/API/Vulkan/Vulkan.hpp"
#endif
