#pragma once

#include "stdafx.hpp"

namespace fox::gfx::imp::api
{
    template<typename...>
    struct InternalView;
}
